(() => {
  const canvas = document.getElementById("vero-animation-bg");
  if (!canvas) return;

  const ctx = canvas.getContext("2d", { alpha: true });
  if (!ctx) return;

  const reduceMotion = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
  let width = 0;
  let height = 0;
  let dpr = 1;
  let raf = 0;
  let start = performance.now();

  const blobs = [
    { color: [245, 166, 35], x: 0.16, y: 0.37, rx: 0.34, ry: 0.34, speed: 0.00022, phase: 0.3 },
    { color: [105, 91, 205], x: 0.79, y: 0.31, rx: 0.31, ry: 0.34, speed: 0.00019, phase: 2.4 },
    { color: [244, 151, 39], x: 0.72, y: 0.82, rx: 0.28, ry: 0.25, speed: 0.00024, phase: 4.5 },
    { color: [65, 76, 158], x: 0.34, y: 0.78, rx: 0.31, ry: 0.26, speed: 0.00017, phase: 5.6 }
  ];

  function resize() {
    dpr = Math.min(window.devicePixelRatio || 1, 2);
    width = window.innerWidth;
    height = window.innerHeight;
    canvas.width = Math.round(width * dpr);
    canvas.height = Math.round(height * dpr);
    canvas.style.width = `${width}px`;
    canvas.style.height = `${height}px`;
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    draw(performance.now());
  }

  function paintBlob(blob, t) {
    const driftX = Math.sin(t * blob.speed + blob.phase) * width * 0.13;
    const driftY = Math.cos(t * blob.speed * 0.82 + blob.phase) * height * 0.16;
    const breathe = 1 + Math.sin(t * blob.speed * 1.7 + blob.phase) * 0.18;
    const x = blob.x * width + driftX;
    const y = blob.y * height + driftY;
    const radius = Math.max(width, height) * blob.rx * breathe;
    const radiusY = Math.max(width, height) * blob.ry * breathe;

    ctx.save();
    ctx.translate(x, y);
    ctx.scale(1, radiusY / radius);
    const g = ctx.createRadialGradient(0, 0, 0, 0, 0, radius);
    const [r, green, b] = blob.color;
    g.addColorStop(0, `rgba(${r},${green},${b},0.22)`);
    g.addColorStop(0.32, `rgba(${r},${green},${b},0.12)`);
    g.addColorStop(1, `rgba(${r},${green},${b},0)`);
    ctx.fillStyle = g;
    ctx.beginPath();
    ctx.arc(0, 0, radius, 0, Math.PI * 2);
    ctx.fill();
    ctx.restore();
  }

  function drawRibbon(t, color, phase, direction, thickness) {
    const scale = Math.min(width, height);
    const yBase = height * (0.48 + Math.sin(t * 0.00018 + phase) * 0.12);
    const amp = height * 0.18;
    const drift = Math.sin(t * 0.00025 + phase) * width * 0.1;

    ctx.save();
    ctx.globalCompositeOperation = "screen";
    ctx.lineCap = "round";
    ctx.lineJoin = "round";

    const gradient = ctx.createLinearGradient(
      width * 0.08 + drift, yBase - amp,
      width * 0.92 - drift, yBase + amp
    );
    gradient.addColorStop(0, `rgba(${color},0)`);
    gradient.addColorStop(0.22, `rgba(${color},0.05)`);
    gradient.addColorStop(0.48, `rgba(${color},0.22)`);
    gradient.addColorStop(0.62, `rgba(${color},0.12)`);
    gradient.addColorStop(1, `rgba(${color},0)`);

    ctx.strokeStyle = gradient;
    ctx.lineWidth = scale * thickness;
    ctx.shadowBlur = scale * 0.045;
    ctx.shadowColor = `rgba(${color},0.18)`;
    ctx.beginPath();
    ctx.moveTo(-width * 0.1, yBase + Math.sin(t * 0.0003 + phase) * amp);
    ctx.bezierCurveTo(
      width * 0.24, yBase - amp * direction + Math.sin(t * 0.00021 + phase) * amp * 0.5,
      width * 0.62, yBase + amp * direction + Math.cos(t * 0.00019 + phase) * amp * 0.55,
      width * 1.1, yBase + Math.cos(t * 0.00027 + phase) * amp
    );
    ctx.stroke();
    ctx.restore();
  }

  function draw(t) {
    ctx.clearRect(0, 0, width, height);

    // Gradientes grandes que atravessam a tela em direções diferentes.
    blobs.forEach(blob => paintBlob(blob, reduceMotion ? start : t));

    if (!reduceMotion) {
      drawRibbon(t, "245,166,35", 0.6, 1, 0.09);
      drawRibbon(t + 1800, "113,103,218", 2.8, -1, 0.075);

      // Pequenos pontos de luz movem-se em trajetórias largas.
      const points = [
        { phase: 0.2, color: "255,205,112", radius: 2.4 },
        { phase: 3.1, color: "166,157,255", radius: 1.8 },
        { phase: 4.7, color: "245,166,35", radius: 1.5 }
      ];
      points.forEach((p, i) => {
        const x = width * (0.5 + 0.36 * Math.sin(t * (0.00022 + i * 0.00002) + p.phase));
        const y = height * (0.5 + 0.3 * Math.cos(t * 0.0002 + p.phase * 1.7));
        const glow = ctx.createRadialGradient(x, y, 0, x, y, 22);
        glow.addColorStop(0, `rgba(${p.color},0.45)`);
        glow.addColorStop(1, `rgba(${p.color},0)`);
        ctx.fillStyle = glow;
        ctx.beginPath();
        ctx.arc(x, y, 22, 0, Math.PI * 2);
        ctx.fill();

        ctx.fillStyle = `rgba(${p.color},0.7)`;
        ctx.beginPath();
        ctx.arc(x, y, p.radius, 0, Math.PI * 2);
        ctx.fill();
      });
    }

    // Camada escura preserva contraste do texto.
    const shade = ctx.createLinearGradient(0, 0, width, height);
    shade.addColorStop(0, "rgba(12,11,24,0.20)");
    shade.addColorStop(0.5, "rgba(12,11,24,0.02)");
    shade.addColorStop(1, "rgba(12,11,24,0.28)");
    ctx.fillStyle = shade;
    ctx.fillRect(0, 0, width, height);

    if (!reduceMotion) raf = requestAnimationFrame(draw);
  }

  window.addEventListener("resize", resize, { passive: true });
  document.addEventListener("visibilitychange", () => {
    if (document.hidden) {
      cancelAnimationFrame(raf);
    } else if (!reduceMotion) {
      raf = requestAnimationFrame(draw);
    }
  });

  resize();
  if (!reduceMotion) raf = requestAnimationFrame(draw);
})();
